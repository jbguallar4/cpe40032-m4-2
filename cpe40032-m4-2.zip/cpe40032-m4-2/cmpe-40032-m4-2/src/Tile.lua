--[[
   CMPE40032
    Candy Crush Clone (Match 3 Game)

    -- Tile Class --



    The individual tiles that make up our game board. Each Tile can have a
    color and a variety, with the varietes adding extra points to the matches.
]]

Tile = Class{}

function Tile:init(x, y, color, variety)
    -- board positions
    self.gridX = x
    self.gridY = y

    -- coordinate positions
    self.x = (self.gridX - 1) * 32
    self.y = (self.gridY - 1) * 32
    self.shine = math.random() > 0.98 and true or false

    -- tile appearance/points
    self.color = color
    self.variety = variety
    self.table = { timer = nil,  factor = 255 }

    
end

function Tile:update(dt)
    
end

--[[
    Function to swap this tile with another tile, tweening the two's positions.
]]
function Tile:swap(tile)

end

function Tile:render(x, y)
    -- draw shadow
    love.graphics.setColor(34, 32, 52, 255)
    love.graphics.draw(gTextures['main'], gFrames['tiles'][self.color][self.variety],
        self.x + x + 2, self.y + y + 2)

    -- draw tile itself
    love.graphics.setColor(255, 255, 255, 255)
    love.graphics.draw(gTextures['main'], gFrames['tiles'][self.color][self.variety],
        self.x + x, self.y + y)
    if self.shine then
        love.graphics.setColor(255, 255, 255, self.table.factor)
            love.graphics.rectangle('fill', (self.gridX - 1) * 32 + (VIRTUAL_WIDTH - 270),
                (self.gridY - 1) * 32 + 18, 30, 30, 4)
           
            if not self.table.timer then     
                self.table.timer = Timer.tween(0.5, {
                    [self.table] = { factor = 0 }
                }):finish(function()
                    Timer.tween(0.5, {
                        [self.table] = { factor = 120 }
                    }):finish(function() 
                        self.table.timer = nil
                    end)
                end)
            end
        end
end